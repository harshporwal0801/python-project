from docx2pdf import convert
docx_file = 'pdf1.docx'
pdf_file = 'sample.pdf'
convert(docx_file, pdf_file)
