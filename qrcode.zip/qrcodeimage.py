import os
# Create dirctory 
if not os.path.isdir("qr_images"):
    os.mkdir("qr_images")