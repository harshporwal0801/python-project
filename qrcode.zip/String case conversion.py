#Case conversion method of string
s= "workholics"

print("s:",s)
print("title case:",s.title())
print("upper case:",s.upper())
print("lower case:",s.lower())
print("capitalize case:",s.capitalize())
print("center case:",s.center(50))
print("center case:",s.center(50,":"))